import time
from pydobot import Dobot

# Replace 'COMX' with your actual COM port, e.g., 'COM3'
port = "COM3"
device = Dobot(port=port, verbose=True)

# Define the matrix dimensions and positions
matrix_rows = 3
matrix_cols = 3
start_x = 200  # Starting X position of the matrix (in mm)
start_y = 0    # Starting Y position of the matrix (in mm)
spacing = 50   # Spacing between the tokens (in mm)

# Define the Z height for picking up and placing the token
z_pickup = -30   # Z position for picking up the token (in mm)
z_hover = 50     # Z position to hover above the token (in mm)

# Function to move to a specific position in the matrix and pick up the token
def pick_token(row, col):
    x = start_x + col * spacing
    y = start_y + row * spacing
    
    # Move to hover above the token
    device.move_to(x, y, z_hover, r=0)
    time.sleep(1)

    # Move down to pick up the token
    device.move_to(x, y, z_pickup, r=0)
    time.sleep(1)

    # Activate suction
    device.suck(True)
    time.sleep(1)

    # Move back up with the token
    device.move_to(x, y, z_hover, r=0)
    time.sleep(1)

# Assuming the token is located at position (1, 1) in the matrix
pick_token(1, 1)

# Deactivate suction after picking up the token
device.suck(False)
time.sleep(1)

# Move to a safe position or home position after operation
device.move_to(200, 0, 50, r=0)  # Adjust these values based on your setup

# Close the connection
device.close()
