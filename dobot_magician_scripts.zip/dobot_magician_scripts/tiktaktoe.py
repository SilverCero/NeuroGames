import socket
import time
import threading
import DobotDllType as dType  # Use the alias for the DobotDllType module

# Define connection parameters
UDP_IP = "192.168.0.135"  # Replace with your target IP
UDP_PORT = 5005  # Example port

# Define the coordinates for the tic-tac-toe board positions
coordinates = {
    1: (110, 50, -10),
    2: (140, 0, -10),
    3: (200, -90, -10),
    4: (110, 50, -10),
    5: (140, 0, -10),
    6: (200, -90, -10),
    7: (110, 50, -10),
    8: (140, 0, -10),
    9: (200, -90, -10),
    0: (-11, -120, -10),  # Coordinates for storing X's and O's
    10: (-11, -120, -10)
}

# Initialize API
api = dType.load()  # Load the Dobot DLL
state = dType.ConnectDobot(api, "COM3", 115200)[0]

# Connection status check
if state != dType.DobotConnect.DobotConnect_NoError:
    print("Failed to connect to the Dobot.")
    exit(1)  # Exit if API loading fails

# Clear the command queue and set motion parameters
dType.SetQueuedCmdClear(api)
dType.SetHOMEParams(api, 200, 200, 200, 200, isQueued=1)
dType.SetPTPCommonParams(api, 100, 100, isQueued=1)

# Function to move the Dobot to a specified position
def move_to_position(position):
    coords = coordinates.get(position)
    if coords:
        print(f"Moving to position {position} with coordinates {coords}")
        dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, coords[0], coords[1], coords[2], 0, isQueued=1)
        dType.SetQueuedCmdStartExec(api)

        # Wait for the command to finish executing
        while dType.GetQueuedCmdCurrentIndex(api)[0] > 0:
            time.sleep(0.1)  # Wait while the command is executing
        print(f"Finished moving to position {position}")
    else:
        print(f"Position {position} not defined.")

# Function to turn the pump on/off
def control_pump(turn_on):
    if turn_on:
        print("Pump ON")
        dType.SetEndEffectorSuctionCup(api, True, True, isQueued=1)  # Activate suction cup
    else:
        print("Pump OFF")
        dType.SetEndEffectorSuctionCup(api, False, False, isQueued=1)  # Deactivate suction cup

# Function to handle robot control based on the received position
def robot_control(position):
    try:
        move_to_position(0)  # Move to start position
        time.sleep(2)  # Wait for the robot to reach the start position

        # Move to the target position based on the received number
        move_to_position(position)
        control_pump(turn_on=True)  # Turn on the pump
        time.sleep(5)  # Wait while the pump is on
        control_pump(turn_on=False)  # Turn off the pump

        move_to_position(0)  # Return to start position
        time.sleep(2)  # Wait for the robot to reach home position
    except Exception as e:
        print(f"Error in robot control: {e}")

# Function to listen for UDP messages and control the robot
def listen_for_messages():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP, UDP_PORT))

    try:
        while True:
            print("Listening for messages...")
            data, addr = sock.recvfrom(1024)  # Buffer size is 1024 bytes
            message = data.decode()
            print(f"Received message: {message}")

            if message.startswith("selection:"):
                try:
                    position = int(message.split(":")[1])
                    threading.Thread(target=robot_control, args=(position,)).start()
                except ValueError:
                    print("Invalid selection number received.")
    except KeyboardInterrupt:
        print("Exiting...")
    finally:
        sock.close()

# Start the robot by moving to position 0
move_to_position(0)

# Run the socket listener in a separate thread
listen_for_messages()
