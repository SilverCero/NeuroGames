import socket
import time
import DobotDllType as dType

# Define connection parameters
UDP_IP = "192.168.0.135"
UDP_PORT = 5005

# Initialize the Dobot API
api = dType.load()
state = dType.ConnectDobot(api, "COM3", 115200)[0]

# Connection status check
if state != dType.DobotConnect.DobotConnect_NoError:
    print("Failed to connect to the Dobot.")
    exit(1)

# Clear the command queue and set motion parameters
dType.SetQueuedCmdClear(api)
dType.SetHOMEParams(api, 200, 200, 200, 200, isQueued=1)
dType.SetPTPCommonParams(api, 100, 100, isQueued=1)

# Home the robot
dType.SetHOMECmd(api, temp=0, isQueued=1)
dType.SetQueuedCmdStartExec(api)

# Wait for homing to complete
while dType.GetQueuedCmdCurrentIndex(api)[0] < 1:
    time.sleep(0.1)

# Function to move the Dobot to a specified position
def move_to_position(x, y, z):
    print(f"Moving to position [{x}, {y}, {z}]")
    queued_cmd_index = dType.SetPTPCmd(api, dType.PTPMode.PTPMOVLXYZMode, x, y, z, 0, isQueued=1)
    
    if queued_cmd_index == -1:
        print("Error queuing the command.")
        return
    
    # Wait for the command to finish
    while dType.GetQueuedCmdCurrentIndex(api)[0] < queued_cmd_index[0]:
        time.sleep(0.1)
    
    print(f"Finished moving to position [{x}, {y}, {z}]")

def robot_control(x, y, z):
    # Move to the target position
    move_to_position(x, y, z)
    time.sleep(5)  # Wait while the pump is on

    move_to_position(200, 124, 70)  # Return to start position
    time.sleep(2)  # Wait for the robot to reach home position

# Function to listen for UDP messages
def listen_for_messages():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((UDP_IP, UDP_PORT))

    try:
        while True:
            print("Listening for messages...")
            data, addr = sock.recvfrom(1024)
            message = data.decode()
            print(f"Received message: {message}")
            
            if message.startswith("selection:"):
                try:
                    return int(message.split(":")[1])
                except ValueError:
                    print("Invalid selection number received.")
    except KeyboardInterrupt:
        print("Exiting...")
    finally:
        sock.close()

# Start the robot by moving to the initial position
move_to_position(200, 124, 70)

# Listen for the target position
target_position = listen_for_messages()

# Move based on the received message
if target_position == 1:
    robot_control(110, 50, -10)
elif target_position == 2:
    robot_control(140, 0, -10)
elif target_position == 3:
    robot_control(200, -90, -10)
elif target_position == 4:
    robot_control(110, 50, -10)
elif target_position == 5:
    robot_control(140, 0, -10)
elif target_position == 6:
    robot_control(200, -90, -10)
elif target_position == 7:
    robot_control(110, 50, -10)
elif target_position == 8:
    robot_control(140, 0, -10)
elif target_position == 9:
    robot_control(200, -90, -10)

# Stop queued commands after finishing
dType.SetQueuedCmdStopExec(api)
